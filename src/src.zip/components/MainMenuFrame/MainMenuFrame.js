import './MainMenuFrame.css';

const MainMenuFrame = (props) => {
    return (
        <div className="main-menu">
            <div className="main-menu__content">


                <ul className="cards__list">
                    <li className="card">
                        <div className="card__content">
                            <div className="card__text">Готовая продукция</div>
                        </div>
                    </li>

                    <li className="card">
                        <div className="card__content">
                            <div className="card__text">
                                <div className="card__title">Проверка и обслуживание весов</div>
                            </div>
                        </div>
                    </li>

                    <li className="card">
                        <div className="card__content">
                            <div className="card__text">
                                <div className="card__title">Контрольное взвешивание</div>
                            </div>
                        </div>
                    </li>

                    <li className="card">
                        <div className="card__content">
                            <div className="card__text">
                                <div className="card__title"></div>
                            </div>
                        </div>
                    </li>

                    <li className="card">
                        <div className="card__content">
                            <div className="card__text">
                                <div className="card__title"></div>
                            </div>
                        </div>
                    </li>

                </ul>
            </div>
        </div>
    );
};

export default MainMenuFrame;
